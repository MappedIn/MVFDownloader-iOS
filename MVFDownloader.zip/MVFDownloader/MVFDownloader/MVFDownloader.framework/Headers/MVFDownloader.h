//
//  MVFDownloader.h
//  MVFDownloader
//
//  Created by Ed Wei on 10/24/19.
//  Copyright © 2019 Mappedin. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MVFDownloader.
FOUNDATION_EXPORT double MVFDownloaderVersionNumber;

//! Project version string for MVFDownloader.
FOUNDATION_EXPORT const unsigned char MVFDownloaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MVFDownloader/PublicHeader.h>


